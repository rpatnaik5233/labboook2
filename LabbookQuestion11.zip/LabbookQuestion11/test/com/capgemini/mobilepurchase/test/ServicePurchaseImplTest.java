package com.capgemini.mobilepurchase.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;
import com.capgemini.mobilepurchase.service.IServicePurchaseMobile;
import com.capgemini.mobilepurchase.service.ServicePurchaseImpl;

public class ServicePurchaseImplTest {
	private PurchaseDetailsBean purchaseDetailsBean;
	@Before
	public void setUp() throws Exception {
		purchaseDetailsBean=new PurchaseDetailsBean("abc","abc@ab.com","9988",1002);
	}

	@After
	public void tearDown() throws Exception {
		purchaseDetailsBean=null;
	}

	@Test
	public final void testInsertPurchaseDetails() {
		IServicePurchaseMobile servicePurchaseMobile = new ServicePurchaseImpl();
		try
		{
		assertTrue(servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean)); 
		}
		catch(MobilePurchaseException e){
			e.printStackTrace();
		}
	}

}
