package com.capgemini.mobilepurchase.exception;

public class MobilePurchaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4717725058466330107L;

	public MobilePurchaseException()
	{
		super();
	}

	public MobilePurchaseException(String message) {
		super(message);
	}
	
}
