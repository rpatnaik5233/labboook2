package com.capgemini.mobilepurchase.pi;

import java.time.LocalDate;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;
import com.capgemini.mobilepurchase.service.IServicePurchaseMobile;
import com.capgemini.mobilepurchase.service.ServicePurchaseImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		
		PurchaseDetailsBean pbd= new PurchaseDetailsBean(1,"abc","abc@ab.com","9988",LocalDate.now(),1002);
		IServicePurchaseMobile isp=new ServicePurchaseImpl();
		try{
			boolean isInserted=isp.insertPurchaseDetails(pbd);
			if(isInserted)
			{
				System.out.println("Record inserted successfully!");
			}
		}
		catch(MobilePurchaseException mpe)
		{
			System.out.println(mpe.getMessage());
		}
		
	}

}
