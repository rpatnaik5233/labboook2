package com.capgemini.mobilepurchase.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.dao.IMobileDAO;
import com.capgemini.mobilepurchase.dao.IPurchaseDetailsDAO;
import com.capgemini.mobilepurchase.dao.MobileDAOImpl;
import com.capgemini.mobilepurchase.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		int mobileQuantity=0;
		boolean isItInserted=false;
		boolean isUpdated=false;
		
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		IMobileDAO mobileDAO= new MobileDAOImpl();
		
		mobileQuantity = mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity>0){
				isItInserted=purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
				mobileQuantity--;
				isUpdated=mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(), mobileQuantity);
		}
		return (isItInserted && isUpdated);
	}


public boolean isValidCName(String cname) throws MobilePurchaseException{
	boolean isValid=false;
	String pattern="[A-Z]{1}[A-za-z]{1,19}";
	Pattern ptn=Pattern.compile(pattern);
	Matcher matcher =ptn.matcher(cname);
	isValid=matcher.matches();
	if(!isValid)
	{
		throw new MobilePurchaseException("Invalid Name.");
	}
	return isValid;
}

public boolean isValidPhoneNo(String phoneNo) throws MobilePurchaseException
{
	boolean isValid=false;
	String pattern="[\\d]{10}";
	
	Pattern ptn=Pattern.compile(pattern);
	Matcher matcher =ptn.matcher(phoneNo);
	isValid=matcher.matches();
	
	if(!isValid)
	{
		throw new MobilePurchaseException("Invalid Phone No.");
	}
	return isValid;
}

public boolean isValidMail(String mail)throws MobilePurchaseException
{
	boolean isValid=false;
	String pattern="[a-z0-9./%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
	
	Pattern ptn=Pattern.compile(pattern);
	Matcher matcher =ptn.matcher(mail);
	isValid=matcher.matches();
	
	if(!isValid)
	{
		throw new MobilePurchaseException("Invalid E-mail Id.");
	}
	return isValid;
}
}
