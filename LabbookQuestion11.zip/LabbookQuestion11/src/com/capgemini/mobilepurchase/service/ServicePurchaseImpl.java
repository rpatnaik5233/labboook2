package com.capgemini.mobilepurchase.service;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.dao.IPurchaseDetailsDAO;
import com.capgemini.mobilepurchase.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		boolean isItInserted=purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
		return isItInserted;
	}

}
