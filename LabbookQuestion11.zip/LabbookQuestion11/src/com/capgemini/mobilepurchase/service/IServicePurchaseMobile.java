package com.capgemini.mobilepurchase.service;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean) 
			throws MobilePurchaseException;
	
	
	
}
