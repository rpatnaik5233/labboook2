package com.capgemini.mobilepurchase.dao;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;

public interface IPurchaseDetailsDAO {
	public boolean insertPurchase
	(final PurchaseDetailsBean purchaseDetailsBean)
	throws MobilePurchaseException;
	
	
	public boolean deletePurchaseDetails(final int mobileId)
	throws MobilePurchaseException;
	
	
}
