package com.capgemini.mobilepurchase.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.mobilepurchase.bean.PurchaseDetailsBean;
import com.capgemini.mobilepurchase.exception.MobilePurchaseException;
import com.capgemini.mobilepurchase.util.DBConnection;

public class PurchaseDetailsDAOImpl implements IPurchaseDetailsDAO {

	@Override
	public boolean insertPurchase(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		int records=0;
		boolean isInserted=false;
try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapperPurchaseDetails.INSERT_PURCHASE);
		)
		{
	java.sql.Date PurchaseDate=new Date(new java.util.Date().getTime());
	preparedStatement.setInt(1, purchaseDetailsBean.getPurchaseId());
	preparedStatement.setString(2, purchaseDetailsBean.getName());
	preparedStatement.setString(3, purchaseDetailsBean.getMailId());
	preparedStatement.setString(4, purchaseDetailsBean.getPhoneNo());
	preparedStatement.setDate(5, PurchaseDate);
	preparedStatement.setInt(6, purchaseDetailsBean.getMobileId());
	records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isInserted=true;
	}
		}catch(SQLException sqlEx)
{
			throw new MobilePurchaseException(sqlEx.getMessage());
}
		return isInserted;
	}

	@Override
	public boolean deletePurchaseDetails(int mobileId)
			throws MobilePurchaseException {
		int records=0;
		boolean isDeleted=false;
try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapperPurchaseDetails.DELETE_PURCHASE);
		)
		{

	preparedStatement.setInt(1,mobileId);
	records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isDeleted=true;
	}
		}catch(SQLException sqlEx)
{
			throw new MobilePurchaseException(sqlEx.getMessage());
}
		return isDeleted;
		}

}
