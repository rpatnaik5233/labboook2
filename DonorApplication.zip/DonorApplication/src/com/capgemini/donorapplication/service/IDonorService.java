package com.capgemini.donorapplication.service;

import java.util.List;

import com.capgemini.donorapplication.bean.DonorBean;
import com.capgemini.donorapplication.exception.MobilePurchaseException;

public interface IDonorService 
{
	public String addDonorDetails(DonorBean donor) throws MobilePurchaseException;
	public DonorBean viewDonorDetails(String donorId) throws MobilePurchaseException;
	public List<DonorBean> retriveAll()throws MobilePurchaseException;
}
