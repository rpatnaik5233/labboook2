package com.capgemini.donorapplication.dao;

import java.util.List;

import com.capgemini.donorapplication.bean.DonorBean;
import com.capgemini.donorapplication.exception.MobilePurchaseException;

public interface IDonorDAO 
{
	public String addDonorDetails(DonorBean donor) throws MobilePurchaseException;
	public DonorBean viewDonorDetails(String donorId) throws MobilePurchaseException;
	public List<DonorBean> retriveAllDetails()throws MobilePurchaseException;
}
