package com.capgemini.donorapplication.exception;

public class MobilePurchaseException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public MobilePurchaseException(String message) 
	{
		
		super(message);
	}
}
