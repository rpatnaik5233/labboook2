package com.capgemini.employeeapplication.dao;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;


public interface IEmployeeDAO {

	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException;
}

