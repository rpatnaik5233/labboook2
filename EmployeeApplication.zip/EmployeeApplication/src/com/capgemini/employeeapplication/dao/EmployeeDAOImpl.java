package com.capgemini.employeeapplication.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;
import com.capgemini.employeeapplication.util.DBConnection;


public class EmployeeDAOImpl implements IEmployeeDAO {
	boolean isInserted=false;
	@SuppressWarnings("deprecation")
	@Override
	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException {

		int records=0;
		boolean isInserted=false;
try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapper.INSERT_QUERY);
		)
		{
	java.sql.Date PurchaseDate=new Date(new java.util.Date().getDate());
	preparedStatement.setString(1,emp.getName());
	preparedStatement.setFloat(2, emp.getSalary());
	preparedStatement.setString(3, emp.getDepartment());
	preparedStatement.setDate(4, PurchaseDate);
	records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isInserted=true;
	}
		}catch(SQLException sqlEx)
{
			throw new EmployeeException(sqlEx.getMessage());
}
		return isInserted;		
		
		}

}
