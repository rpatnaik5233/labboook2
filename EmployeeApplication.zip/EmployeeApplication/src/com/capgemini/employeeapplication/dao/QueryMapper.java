package com.capgemini.employeeapplication.dao;

public interface QueryMapper {

	public static final String INSERT_QUERY="INSERT INTO employee VALUES(employee_sequence.NEXTVAL,?,?,?,?)";
	

}
